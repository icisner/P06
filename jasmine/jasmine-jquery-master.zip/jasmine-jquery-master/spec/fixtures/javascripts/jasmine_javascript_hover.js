$(function (){ $('#anchor_01').on('hover', function(){ $(this).addClass('bar'); }) });
